PT1
To run the calendar program, navigate to the CalendarApp.java file in the src folder.
This is the entry point for the program.
Run the file and pass in either '--interactive', or '--headless <filepath>' configuration commands.

The design for the model was a combined effort (builder pattern, fields, methods).
Model method implementations were done by Thomas. 
Controller methods and design was done by Jeffrey.
Program entry point (CalendarApp) was a combined effort.
Event and Calendar Tests were done by Thomas.
Controller and App tests were done by Jeffrey.
View was done by Jeffrey.

The some_invalid_commands.txt file contains invalid commands at the top and their corresponding
valid versions on the bottom.

PT2
Changes made:
- new class for user which implements an interface that extends the calendar interface. 
    This is because the user class can do everything the calendar class can do and apply it 
    to the current calendar.
- new implementation for a calendar called UserCalendar which contains information on the timezone.
    This extends the SimpleCalendar class because it can do everything a SimpleCalendar can do 
    and more including methods that help copying function.
- 