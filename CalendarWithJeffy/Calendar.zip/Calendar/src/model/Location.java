package model;

/**
 * an enum representing the location of an event.
 */
public enum Location {
  NONSPECIFIC, ONLINE, PHYSICAL
}
