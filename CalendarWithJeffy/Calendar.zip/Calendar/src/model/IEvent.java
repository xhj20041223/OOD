package model;

import java.time.LocalDateTime;

/**
 * interface for an event implementation.
 */
public interface IEvent extends Comparable<IEvent> {
  //compare two events is equal or not with the same subject, start date/time and end date/time.

  /**
   * gets the start date of this event with time.
   *
   * @return the start date of this event with time.
   */
  public LocalDateTime getStartDateTime();

  /**
   * gets the end date of this event with time.
   *
   * @return the end date of this event with time.
   */
  public LocalDateTime getEndDateTime();

  /**
   * gets the subject of this event.
   *
   * @return the subject of this event.
   */
  public String getSubject();

  /**
   * gets the description of this event.
   *
   * @return the description of this event.
   */
  public String getDescription();

  /**
   * get the location of this event.
   *
   * @return the location of this event.
   */
  public Location getLocation();

  /**
   * get the status of this event.
   *
   * @return the status of this event.
   */
  public Status getStatus();

  /**
   * compares the dates of this event and the given event.
   *
   * @param event the object to be compared.
   * @return -1 if this event comes before the given event,
   *          0 if this event has the same date as the given event,
   *          1 if this event comes after the given event.
   */
  public int compareTo(IEvent event);

  /**
   * sets the subject of this event.
   *
   * @param subject this events new subject.
   */
  public void setSubject(String subject);

  /**
   * sets the start date and time of this event.
   *
   * @param startDateTime this events new start date with time.
   */
  public void setStartDateTime(LocalDateTime startDateTime);

  /**
   * sets the end date and time of this event.
   *
   * @param endDateTime this events new end date with time.
   */
  public void setEndDateTime(LocalDateTime endDateTime);

  /**
   * sets the description of this event.
   *
   * @param description this event's new description.
   */
  public void setDescription(String description);

  /**
   * sets the location of this event.
   *
   * @param location this event's new description.
   */
  public void setLocation(Location location);

  /**
   * sets the status of this event.
   *
   * @param status this event's new status.
   */
  public void setStatus(Status status);
}
