package model;

/**
 * and enum that represents the status of an event.
 */
public enum Status {
  NONSPECIFIC, PRIVATE, PUBLIC
}
