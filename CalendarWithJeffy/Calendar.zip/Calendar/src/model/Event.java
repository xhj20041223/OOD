package model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * represents an event implementation with a subject, start time, end time,
 * and optionally description, location and status.
 */
public class Event implements IEvent, Comparable<IEvent> {

  private String subject;
  private LocalDateTime start;
  private LocalDateTime end;
  private String description;
  private Location location;
  private Status status;

  private Event(String subject, LocalDateTime start, LocalDateTime end, String description,
                Location location, Status status) {
    this.subject = subject;
    this.start = start;
    this.end = end;
    this.description = description;
    this.location = location;
    this.status = status;
  }

  /**
   * Builder class for an event.
   */
  public static class EventBuilder {
    private String subject;
    private LocalDateTime start;
    private LocalDate fullDayDate;
    private LocalDateTime end;
    private String description;
    private Location location;
    private Status status;

    /**
     * constructs a builder for an event.
     */
    public EventBuilder() {
      this.description = "";
      this.location = Location.NONSPECIFIC;
      this.status = Status.NONSPECIFIC;
    }

    /**
     * Sets the subject for this event builder.
     * @param subject the subject to be set.
     * @return the event builder with the newly set field.
     */
    public EventBuilder setSubject(String subject) {
      this.subject = subject;
      return this;
    }

    /**
     * Sets the start LocalDateTime for this event builder.
     * @param start the date time to be set.
     * @return the event builder with the newly set field.
     */
    public EventBuilder setStart(LocalDateTime start) {
      this.start = start;
      return this;
    }

    /**
     * Sets the date for this event builder.
     * @param fullDayDate the date to be set.
     * @return the event builder with the newly set field.
     */
    public EventBuilder setFullDayDate(LocalDate fullDayDate) {
      this.fullDayDate = fullDayDate;
      return this;
    }

    /**
     * sets the end date time of this event builder.
     * @param end the end date time to be set.
     * @return the event builder with the newly set field.
     */
    public EventBuilder setEnd(LocalDateTime end) {
      this.end = end;
      return this;
    }

    /**
     * sets the description of this event builder.
     * @param description the description to be set.
     * @return the event builder with the newly set field.
     */
    public EventBuilder setDescription(String description) {
      this.description = description;
      return this;
    }

    /**
     * sets the location of this event builder.
     * @param location the location ot be set.
     * @return the event builder with the newly set field.
     */
    public EventBuilder setLocation(String location) {
      this.location = Location.valueOf(location.toUpperCase());
      return this;
    }

    /**
     * sets the status of this event builder.
     * @param status the status to be set.
     * @return this event builder with the newly set field.
     */
    public EventBuilder setStatus(String status) {
      this.status = Status.valueOf(status.toUpperCase());
      return this;
    }

    /**
     * builds the Event using this event builder.
     * @return an Event built with the event builder.
     */
    public Event build() {
      if (this.fullDayDate != null) {
        this.start = this.fullDayDate.atTime(8, 0);
        this.end = this.fullDayDate.atTime(17, 0);
      }
      if (subject == null || start == null || subject.trim().isEmpty()) {
        throw new IllegalStateException("Event should have at least subject and start time");
      }

      if (this.end == null) {
        throw new IllegalArgumentException("End time cannot be null if the event is not full day " +
                "event");
      }
      if (this.end.isBefore(this.start)) {
        throw new IllegalArgumentException("End time cannot be before start time");
      }

      return new Event(this.subject, this.start, this.end, this.description, this.location,
              this.status);
    }
  }

  /**
   * Is this event the same as the given event.
   *
   * @param event the event to be compared with.
   * @return whether or not this object is the same as the given event.
   */
  @Override
  public boolean equals(Object event) {
    if (event instanceof Event) {
      IEvent e = (IEvent) event;
      return (this.subject.equals((e.getSubject()))
              && this.getStartDateTime().equals(e.getStartDateTime())
              && this.getEndDateTime().equals(e.getEndDateTime()));
    }
    return false;
  }

  // override hashcode because we override equals

  /**
   * Returns a hash code value for the object.
   *
   * @return a hash code value for the object.
   */
  @Override
  public int hashCode() {
    return this.subject.hashCode()
            + this.getStartDateTime().hashCode()
            + this.getEndDateTime().hashCode();
  }

  /**
   * gets the start date of this event with time.
   *
   * @return the start date of this event with time.
   */
  @Override
  public LocalDateTime getStartDateTime() {
    return this.start;
  }

  /**
   * gets the end date of this event with time.
   *
   * @return the end date of this event with time.
   */
  @Override
  public LocalDateTime getEndDateTime() {
    return this.end;
  }

  /**
   * gets the subject of this event.
   *
   * @return the subject of this event.
   */
  @Override
  public String getSubject() {
    return this.subject;
  }

  /**
   * gets the description of this event.
   *
   * @return the description of this event.
   */
  @Override
  public String getDescription() {
    if (this.description.isEmpty()) {
      throw new IllegalStateException("The description is empty");
    }
    return this.description;
  }

  /**
   * get the location of this event.
   *
   * @return the location of this event.
   */
  @Override
  public Location getLocation() {
    if (this.location == Location.NONSPECIFIC) {
      throw new IllegalStateException("Event have not specified location");
    }
    return this.location;
  }

  /**
   * get the status of this event.
   *
   * @return the status of this event.
   */
  @Override
  public Status getStatus() {
    if (this.status == Status.NONSPECIFIC) {
      throw new IllegalStateException("Event have not specified status");
    }
    return this.status;
  }

  /**
   * compares the dates of this event and the given event.
   *
   * @param event the object to be compared.
   * @return -1 if this event comes before the given event,
   *          0 if this event has the same date as the given event,
   *          1 if this event comes after the given event.
   */
  @Override
  public int compareTo(IEvent event) {
    if (this.start.equals(event.getStartDateTime())) {
      return this.end.compareTo(event.getEndDateTime());
    }
    return this.start.compareTo(event.getStartDateTime());
  }

  /**
   * sets the subject of this event.
   *
   * @param subject this events new subject.
   */
  @Override
  public void setSubject(String subject) {
    this.subject = subject;
  }

  /**
   * sets the start date and time of this event.
   *
   * @param startDateTime this events new start date with time.
   */
  @Override
  public void setStartDateTime(LocalDateTime startDateTime) {
    if (!startDateTime.isBefore(this.end)) {
      throw new IllegalArgumentException("Start time cannot be before end time");
    }
    this.start = startDateTime;
  }

  /**
   * sets the end date and time of this event.
   *
   * @param endDateTime this events new end date with time.
   */
  @Override
  public void setEndDateTime(LocalDateTime endDateTime) {
    if (!endDateTime.isAfter(this.start)) {
      throw new IllegalArgumentException("Start time cannot be before end time");
    }
    this.end = endDateTime;
  }

  /**
   * sets the description of this event.
   *
   * @param description this event's new description.
   */
  @Override
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * sets the location of this event.
   *
   * @param location this event's new description.
   */
  @Override
  public void setLocation(Location location) {
    this.location = location;
  }

  /**
   * sets the status of this event.
   *
   * @param status this event's new status.
   */
  @Override
  public void setStatus(Status status) {
    this.status = status;
  }

  /**
   * returns this event as a string representation containing relevant
   *      information on the status, time, date, location, description.
   *
   * @return string representation of an event.
   */
  @Override
  public String toString() {
    StringBuilder str = new StringBuilder();
    switch (this.status) {
      case NONSPECIFIC:
        str.append("• An event: ");
        break;
      case PRIVATE:
        str.append("• A private event: ");
        break;
      case PUBLIC:
        str.append("• A public event: ");
        break;
      default:
        break;
    }
    str.append(this.subject + " will be from " + this.start + " to " + this.end);
    switch (this.location) {
      case ONLINE:
        str.append(" online.");
        break;
      case PHYSICAL:
        str.append(" in person.");
        break;
      default:
        str.append(".");
        break;
    }
    if (!this.description.isEmpty()) {
      str.append("\nDescription: " + this.description + ".");
    }
    return str.toString();
  }
}
