package model;

/**
 * an enum representing hashmap keys for event properties.
 */
public enum Properties {
  END_TIME, LOCATION, DESCRIPTION, STATUS, START_TIME, SUBJECT
}
