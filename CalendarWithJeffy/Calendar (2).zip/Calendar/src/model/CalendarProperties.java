package model;

/**
 * an enum representing hashmap keys for calendar properties.
 */
public enum CalendarProperties {
  NAME, TIMEZONE;
}
