package model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.time.DayOfWeek;

import static java.time.format.DateTimeFormatter.ISO_LOCAL_DATE;

/**
 * a calendar implementation.
 */
public class SimpleCalendar implements Calendar {
  protected final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
  protected final ArrayList<ArrayList<IEvent>> eventSeriesList;
  protected final ArrayList<IEvent> events;

  /**
   * constructor for SimpleCalendar.
   */
  public SimpleCalendar() {
    this.events = new ArrayList<IEvent>();
    this.eventSeriesList = new ArrayList<ArrayList<IEvent>>();
  }

  /**
   * Creates and event with the given parameters and adds it to the events list in this calendar.
   *
   * @param subject   the subject of the event.
   * @param start     the start LocalDateTime of the event.
   * @param optionals the hashmap that contains additional features of the event.
   * @return the newly created event.
   */
  @Override
  public IEvent createEvent(String subject, String start, HashMap<Properties, String> optionals) {
    Event.EventBuilder builder = new Event.EventBuilder();
    builder.setSubject(subject);
    if (optionals.containsKey(Properties.END_TIME)) {
      if (LocalDateTime.parse(start, FORMATTER)
              .isAfter(LocalDateTime.parse(optionals.get(Properties.END_TIME), FORMATTER))) {
        throw new IllegalArgumentException("End time should be after the start time");
      }
      builder.setStart(LocalDateTime.parse(start, FORMATTER));
      builder.setEnd(LocalDateTime.parse(optionals.get(Properties.END_TIME), FORMATTER));
    } else {
      builder.setFullDayDate(LocalDate.parse(start, ISO_LOCAL_DATE));
    }
    if (optionals.containsKey(Properties.DESCRIPTION)) {
      builder.setDescription(optionals.get(Properties.DESCRIPTION));
    }
    if (optionals.containsKey(Properties.STATUS)) {
      builder.setStatus(optionals.get(Properties.STATUS));
    }
    if (optionals.containsKey(Properties.LOCATION)) {
      builder.setLocation(optionals.get(Properties.LOCATION));
    }
    IEvent event = builder.build();
    if (this.events.contains(event)) {
      throw new IllegalArgumentException("Event already exists");
    }
    this.events.add(event);
    Collections.sort(this.events);
    return event;
  }

  /**
   * Creates a series of events as a list of events using the given parameters
   * and adds it to the map of event series' in this calendar.
   *
   * @param subject   the subject of the events.
   * @param start     the start date of the events.
   * @param optionals the hashmap that contains additional features for the events.
   * @param weekDays  the weekdays that the event should be repeated on.
   * @param endDate   the end date of the events.
   */
  @Override
  public void createEventSeries(String subject, String start,
                                HashMap<Properties, String> optionals, String weekDays,
                                String endDate) {
    ArrayList<IEvent> eventSeries = new ArrayList<IEvent>();
    ArrayList<DayOfWeek> days = this.convertWeekDays(weekDays);
    LocalDate startDate;
    if (optionals.containsKey(Properties.END_TIME)) {
      startDate = LocalDate.from(LocalDateTime.parse(start, FORMATTER));
    } else {
      startDate = LocalDate.parse(start, ISO_LOCAL_DATE);
    }
    while (!startDate.isAfter(LocalDate.parse(endDate, ISO_LOCAL_DATE))) {
      if (days.contains(startDate.getDayOfWeek())) {
        if (optionals.containsKey(Properties.END_TIME)) {
          optionals.replace(Properties.END_TIME,
                  startDate.format(ISO_LOCAL_DATE)
                          + optionals.get(Properties.END_TIME).substring(10));
          eventSeries.add(this.createEvent(subject,
                  startDate.format(ISO_LOCAL_DATE)
                          + start.substring(10), optionals));

        } else {
          eventSeries.add(this.createEvent(subject, startDate.format(ISO_LOCAL_DATE), optionals));
        }
      }
      startDate = startDate.plusDays(1);
    }
    this.eventSeriesList.add(eventSeries);
  }

  /**
   * Creates a series of events as a list of events using the given parameters
   * and adds it to the map of event series' in this calendar.
   *
   * @param subject     the subject of the events.
   * @param start       the start date of the events.
   * @param optionals   the hashmap that contains additional features for the events.
   * @param weekDays    the weekdays that the event should be repeated on.
   * @param repeatTimes the total number of events you want in your series.
   */
  @Override
  public void createEventSeries(String subject, String start,
                                HashMap<Properties, String> optionals, String weekDays,
                                int repeatTimes) {
    ArrayList<IEvent> eventSeries = new ArrayList<IEvent>();
    ArrayList<DayOfWeek> days = this.convertWeekDays(weekDays);
    LocalDate startDate;
    if (optionals.containsKey(Properties.END_TIME)) {
      startDate = LocalDate.from(LocalDateTime.parse(start, FORMATTER));
    } else {
      startDate = LocalDate.parse(start, ISO_LOCAL_DATE);
    }
    while (repeatTimes > 0) {
      if (days.contains(startDate.getDayOfWeek())) {
        if (optionals.containsKey(Properties.END_TIME)) {
          optionals.replace(Properties.END_TIME,
                  startDate.format(ISO_LOCAL_DATE)
                          + optionals.get(Properties.END_TIME).substring(10));
          eventSeries.add(this.createEvent(subject,
                  startDate.format(ISO_LOCAL_DATE)
                          + start.substring(10), optionals));

        } else {
          eventSeries.add(this.createEvent(subject, startDate.format(ISO_LOCAL_DATE), optionals));
        }
        repeatTimes--;
      }
      startDate = startDate.plusDays(1);
    }
    this.eventSeriesList.add(eventSeries);
  }

  /**
   * Edits or adds a property of an event.
   *
   * @param subject  the subject of the event you want to change.
   * @param start    the start date of the event you want to change.
   * @param end      the end date of the event you want to change.
   * @param property the property of the event you want to change
   * @param newValue the new value you want to change the property to.
   * @return the newly changed event.
   */
  @Override
  public IEvent editProperty(String subject, String start, String end, Properties property,
                             String newValue) {
    IEvent target = this.findEvent(subject, start, end);
    return this.editEvent(target, property, newValue);
  }

  /**
   * Edits or adds properties of an event.
   *
   * @param subject    the subject of the event you want to change.
   * @param start      the start date of the event you want to change.
   * @param properties the properties of the event you want to change.
   * @param newValue   the new value you want to change the property to.
   */
  @Override
  public void editProperties(String subject, String start, Properties properties, String newValue) {
    ArrayList<IEvent> targets;
    try {
      targets = this.findEventSeries(subject, start);
    } catch (Exception e) {
      IEvent target = this.findEvent(subject, start);
      this.editProperty(subject, target.getStartDateTime().format(FORMATTER),
              target.getEndDateTime().format(FORMATTER), properties, newValue);
      return;
    }

    if (properties == Properties.START_TIME) {
      ArrayList<IEvent> newSeries = new ArrayList<IEvent>();
      for (IEvent target : targets) {
        if (!target.getStartDateTime().isBefore(LocalDateTime.parse(start, FORMATTER))) {
          newSeries.add(this.editEvent(target, properties,
                  target.getStartDateTime().format(ISO_LOCAL_DATE) + newValue.substring(10)));
        }
      }
      this.eventSeriesList.add(newSeries);
      targets.removeAll(newSeries);
    } else if (properties == Properties.END_TIME) {
      for (IEvent target : targets) {
        if (!target.getStartDateTime().isBefore(LocalDateTime.parse(start, FORMATTER))) {
          this.editEvent(target, properties,
                  target.getEndDateTime().format(ISO_LOCAL_DATE) + newValue.substring(10));
        }
      }
    } else {
      for (IEvent target : targets) {
        if (!target.getStartDateTime().isBefore(LocalDateTime.parse(start, FORMATTER))) {
          this.editEvent(target, properties, newValue);
        }
      }
    }
  }

  /**
   * Edits or adds properties of an event series.
   *
   * @param subject    the subject of the events you want to change.
   * @param start      the start date of the events you want to change.
   * @param properties the properties of the events you want to change.
   * @param newValue   the new value you want to change the property to.
   */
  @Override
  public void editSeriesProperties(String subject, String start, Properties properties,
                                   String newValue) {
    ArrayList<IEvent> targets;
    try {
      targets = this.findEventSeries(subject, start);
    } catch (Exception e) {
      IEvent target = this.findEvent(subject, start);
      this.editProperty(subject, target.getStartDateTime().format(FORMATTER),
              target.getEndDateTime().format(FORMATTER), properties,
              target.getStartDateTime().format(ISO_LOCAL_DATE) + newValue.substring(10));
      return;
    }

    if (properties == Properties.START_TIME) {
      ArrayList<IEvent> newSeries = new ArrayList<IEvent>();
      for (IEvent target : targets) {
        newSeries.add(this.editEvent(target, properties, newValue));
      }
      this.eventSeriesList.add(newSeries);
      targets.removeAll(newSeries);
    } else if (properties == Properties.END_TIME) {
      for (IEvent target : targets) {
        this.editEvent(target, properties,
                target.getEndDateTime().format(ISO_LOCAL_DATE) + newValue.substring(10));
      }
    } else {
      for (IEvent target : targets) {
        this.editEvent(target, properties, newValue);

      }
    }
  }

  /**
   * lists the events on the given date.
   *
   * @param date represents a date of a day with year,month, and day.
   * @return a list of the events on the given date.
   */
  @Override
  public String showEvents(String date) {
    StringBuilder result = new StringBuilder();
    LocalDate localDate = LocalDate.parse(date, ISO_LOCAL_DATE);
    for (IEvent event : this.events) {
      if (!localDate.isBefore(event.getStartDateTime().toLocalDate())
              && !localDate.isAfter(event.getEndDateTime().toLocalDate())) {
        if (result.length() > 0) {
          result.append("\n");
        }

        result.append(event.toString());
      } else if (!localDate.isAfter(event.getStartDateTime().toLocalDate())) {
        break;
      }
    }
    return result.toString();
  }

  /**
   * lists the events happening in the given date range.
   *
   * @param start represents a start date.
   * @param end   represents an end date.
   * @return a list of the events in the given date range.
   */
  @Override
  public String showEvents(String start, String end) {
    StringBuilder result = new StringBuilder();
    LocalDateTime startTime = LocalDateTime.parse(start, FORMATTER);
    LocalDateTime endTime = LocalDateTime.parse(end, FORMATTER);
    for (IEvent event : this.events) {
      if (!startTime.isAfter(event.getEndDateTime())
              && !endTime.isBefore(event.getStartDateTime())) {
        if (result.length() > 0) {
          result.append("\n");
        }
        result.append(event.toString());
      } else if (endTime.isBefore(event.getStartDateTime())) {
        break;
      }
    }
    return result.toString();
  }

  /**
   * shows if there is an event planned for this date time.
   *
   * @param time represents a date time with year, month, day, hour, and minute.
   * @return a string message that says if there is an event planned for this date time.
   */
  @Override
  public String showStatus(String time) {
    LocalDateTime dateTime = LocalDateTime.parse(time, FORMATTER);
    for (IEvent event : this.events) {
      if (!dateTime.isBefore(event.getStartDateTime())
              && !dateTime.isAfter(event.getEndDateTime())) {
        return "You have an event at that time";
      } else if (!dateTime.isAfter(event.getStartDateTime())) {
        break;
      }
    }
    return "You are free at that time";
  }

  // find an event with the targeted subject, start time and end time
  // an IllegalArgumentException will throw if there is no such event
  private IEvent findEvent(String subject, String start, String end) {
    IEvent target =
            new Event.EventBuilder().setSubject(subject).setStart(LocalDateTime.parse(start,
                    FORMATTER)).setEnd(LocalDateTime.parse(end, FORMATTER)).build();
    for (IEvent event : events) {
      if (event.equals(target)) {
        return event;
      }
    }
    throw new IllegalArgumentException("No such event");
  }

  // find an event after the start date time with the targeted subject
  // an IllegalArgumentException will throw if there is no such event
  // an IllegalArgumentException will throw if multiple events satisfied the requirement
  protected IEvent findEvent(String subject, String start) {
    IEvent target = null;
    for (IEvent event : events) {
      if (event.getSubject().equals(subject)
              && !event.getStartDateTime().isBefore(LocalDateTime.parse(start, FORMATTER))) {
        if (target != null) {
          throw new IllegalArgumentException("Multiple events satisfied");
        }
        target = event;
      }
    }
    if (target == null) {
      throw new IllegalArgumentException("No such event");
    } else {
      return target;
    }
  }

  // find the event series after the start date with the targeted subject
  // an IllegalArgumentException will throw if there is no such event series
  private ArrayList<IEvent> findEventSeries(String subject, String start) {
    for (ArrayList<IEvent> events : eventSeriesList) {
      for (IEvent event : events) {
        if (event.getSubject().equals(subject)
                && LocalDateTime.parse(start, FORMATTER).isBefore(event.getStartDateTime())) {
          return events;
        }
      }
    }
    throw new IllegalArgumentException("No such Event Series");
  }

  // convert String weekDays to ArrayList<DayOfWeek>
  // an IllegalArgumentException will throw if the character is invalid
  private ArrayList<DayOfWeek> convertWeekDays(String weekDays) {

    ArrayList<DayOfWeek> days = new ArrayList<DayOfWeek>();
    for (char c : weekDays.toCharArray()) {
      switch (c) {
        case 'M':
          days.add(DayOfWeek.MONDAY);
          break;
        case 'T':
          days.add(DayOfWeek.TUESDAY);
          break;
        case 'W':
          days.add(DayOfWeek.WEDNESDAY);
          break;
        case 'R':
          days.add(DayOfWeek.THURSDAY);
          break;
        case 'F':
          days.add(DayOfWeek.FRIDAY);
          break;
        case 'S':
          days.add(DayOfWeek.SATURDAY);
          break;
        case 'U':
          days.add(DayOfWeek.SUNDAY);
          break;
        default:
          throw new IllegalArgumentException("Invalid weekday: " + c);
      }
    }
    if (days.isEmpty()) {
      throw new IllegalArgumentException("No available weekday");
    }
    return days;
  }


  // edit the property of the targeted event with the newValue
  // will return the updated IEvent if succeed
  private IEvent editEvent(IEvent target, Properties property, String newValue) {
    switch (property) {
      case SUBJECT:
        if (this.events.contains(
                new Event.EventBuilder()
                        .setSubject(newValue)
                        .setStart(target.getStartDateTime())
                        .setEnd(target.getEndDateTime()).build())) {
          throw new IllegalArgumentException("Event after editing already exists");
        }
        target.setSubject(newValue);
        break;
      case DESCRIPTION:
        target.setDescription(newValue);
        break;
      case STATUS:
        target.setStatus(Status.valueOf(newValue.toUpperCase()));
        break;
      case LOCATION:
        target.setLocation(Location.valueOf(newValue.toUpperCase()));
        break;
      case START_TIME:
        if (this.events.contains(
                new Event.EventBuilder()
                        .setSubject(target.getSubject())
                        .setStart(LocalDateTime.parse(newValue, FORMATTER))
                        .setEnd(target.getEndDateTime()).build())) {
          throw new IllegalArgumentException("Event after editing already exists");
        }
        if (!LocalDateTime.parse(newValue, FORMATTER).equals(target.getStartDateTime())) {
          target.setStartDateTime(LocalDateTime.parse(newValue, FORMATTER));
          Collections.sort(this.events);
        }
        break;
      case END_TIME:
        if (this.events.contains(
                new Event.EventBuilder()
                        .setSubject(target.getSubject())
                        .setStart(target.getStartDateTime())
                        .setEnd(LocalDateTime.parse(newValue, FORMATTER)).build())) {
          throw new IllegalArgumentException("Event after editing already exists");
        }
        target.setEndDateTime(LocalDateTime.parse(newValue, FORMATTER));
        Collections.sort(this.events);
        break;
      default:
        break;
    }
    return target;
  }
}
